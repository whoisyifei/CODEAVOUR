# IMED
## Server Environment Setup
```cmd
pip install Flask flask_sqlalchemy flask_cors psycopg2
```
### Note: If psycopg2 fails to install, try:
```cmd
pip install psycopg2-binary
```

## Create Database with SQLAlchemy (PostgreSQL recommended)

### Download PostgreSQL
```
Download from https://www.postgresql.org/download/windows/
```

```cmd
psql -U postgres
```

### Set up database and user
```cmd
CREATE DATABASE patientdb;
CREATE USER imed WITH PASSWORD 'imed';
GRANT ALL PRIVILEGES ON DATABASE patientdb TO imed;
\q
```

```cmd
GRANT CREATE, USAGE ON SCHEMA public TO imed;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO imed;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO imed;
```

```cmd
\l
ALTER DATABASE patientdb OWNER TO imed;
ALTER ROLE imed SET search_path TO public;
```
## Postman
### Insatll Postman
```
Download from https://www.postman.com/downloads/
```

### Open and create a request
1. Open Postman
2. Click "New" → "HTTP Request" or use the "+ New Tab"
3. At the top, choose your HTTP method: GET, POST, PUT, or DELETE
4. Enter the URL — for example:
```cmd
http://localhost:5000/patients
```

### Different HTTP methods
1. GET
   - Method : GET
   - URL: http://localhost:5000/patients
   - Click Send
   - You’ll see a list of all patients from the database in the response<br><br>
2. POST
   - Method : POST
   - URL: http://localhost:5000/admit
   - Body tab → choose raw → select JSON format
   - Paste example JSON:
   - Click Send
```cmd
{
  "name": "John Doe",
  "status": "admitted",
  "diagnostics": "Diabetes Type II",
  "prescriptions": "Metformin",
  "room_number": "A101"
}
```
