# --------------------- Modules ----->
import pyqrcode
import firebase_admin
from firebase_admin import db
from firebase_admin import credentials

# --------------------- Setup ----->
medicine=["Paracetamol",
          "Penicillin",
          "Vitamin C",
          "Vitamin D",
          "Vicodin",
          "Vitamin E",
          "Panadol"]

cred = credentials.Certificate(r"/home/pi/IMEDV3/fbKey/imed-5b179-firebase-adminsdk-419n5-d2f2b0c3f4.json")

firebase_admin.initialize_app(cred,{
    "databaseURL":"https://imed-5b179-default-rtdb.asia-southeast1.firebasedatabase.app/"
})

users_ref = db.reference('medical log/patients/ID')
details = users_ref.get()
patientID = input("id:")
name = patientID
medicines = details[name]["medications"]
medicat = []
for item in medicines:
    if medicines[item]!=0:
        medicat.append([item, medicines[item]])
    else:
        pass

print(details[name])
print(medicat)
