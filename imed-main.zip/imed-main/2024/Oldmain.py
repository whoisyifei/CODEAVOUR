from QR_gen import check_in_patient
from motor_control import motorPos
from cameraPi import StartCamera
from pynput.keyboard import Key, Listener
from time import sleep

import json
import sys

# KingIMED@#123456

print("IMED SYSTEM")
print("Press 'E' to continue...")

def main():
    while True:
        main_menu()

def main_menu():
    print("------------------------------------")
    print("i. Check In")
    print("o. Check Out")
    print("l. Patient List")
    print("s. Scan QR code")
    print("q. Exit\n")
    
    command = str(input("Enter a command: "))
    
    if command == "i":
        print("\nCheck In")
        check_in_patient()
        
    elif command == "o":
        print("\nCheck Out")
        
    elif command == "l":
        print("\nPatient List")
        try:
            with open("patient_data.json", "r") as file:
                data = json.load(file)
        except FileNotFoundError:
            data = []
            
        print(data)
        
    elif command == "s":
        Data = []
        print("Starting Camera ePreview...")
        sleep(1)
        Data = StartCamera()
        print(Data['name'], Data['patient_code'])
        pos = Data.get('medicine_data')
        for i in pos:
            x = pos.get(i)
            print(i)
            print(x)
            motorPos(i, x)
        
    elif command == "q":
        sys.exit(0)
    else:
        print("Invalid Command!")
    

def on_press(key):
    try:
        if key.char == 'e':
            main()
            return False

    except AttributeError:
        # Handle special keys
        if key == Key.space:
            pass
        elif key == Key.enter:
            pass
        elif key == Key.esc:
            pass
        else:
            pass

# Create a listener
with Listener(on_press = on_press) as listener:
    listener.join() 