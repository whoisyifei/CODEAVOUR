### System 2: Raspberry Pi 4 (Client that Fetches Data & Controls Machine)
# Run this on Raspberry Pi
import buzzer_control
import time

def check_medication():
    while True:
        try:
            response = buzzer_control.get("http://<MAIN_SYSTEM_IP>:5000/get_schedule")
            data = response.json()
            if data:
                for patient in data:
                    print(f"Administering medication for {patient[1]} (Bed {patient[6]})")
                    trigger_machine(patient[1])
        except Exception as e:
            print("Error fetching data:", e)
        time.sleep(60)  # Check every minute

def trigger_machine(patient_name):
    print(f"Machine triggered for {patient_name}")
    # Add GPIO control code here to activate a dispenser, alarm, etc.

if __name__ == "__main__":
    check_medication()