# --------------------- Modules ----->
import pyqrcode
import png
import json

# --------------------- Setup ----->

# --------------------- Functions ----->
def generate_QRcode(info, name):
    # Convert patient_info to a string
    patient_info_str = str(info)

    s = patient_info_str
    # Generate QR code
    url = pyqrcode.create(s)
    # Create and save the png file naming "myqr.png"
    url.png(f'QRcode/{name}.png', scale=6)
    
def getData():
    name = input("Enter patient's name: ")
    age = input("Enter patient's age: ")
    phno = input("Enter patient's phone number: ")
    height = input("Enter patient's height (cm): ")
    weight = input("Enter patient's weight (kg): ")
    sickness = input("Enter patient's sickness: ")
    medicine_in = input("Enter prescribed medicine [A, B, C, D, E, F, G, H, I, J, K, L, M, N]: ")
    medicine_list = medicine_in.split()
    medicine_count = {medicine : medicine_list.count(medicine) for medicine in set(medicine_list)}
    medicine_amt = {}
    for medicine in medicine_count:
        amt = input(f"Enter the amount of medicine '{medicine}': ")
        medicine_amt[medicine] = int(amt)
    print(medicine_amt)
    time = input("Enter time of medicine (e.g., morning, evening): ")
    room = input("Enter room number: ")
    bed = input("Enter bed number: ")
    code = input("Enter patient's unique code: ")
    return name, age, phno, height, weight, sickness, medicine_amt, time, room, bed, code

def check_in_patient():
    name, age, phno, height, weight, sickness, medicine_amt, time, room, bed, code = getData()
    patient_info = {
        "name": name,
        "age": age,
        "phone_no": phno,
        "height (cm)": height,
        "weight (kg)": weight,
        "sickness": sickness,
        "medicine_data" : medicine_amt,
        "time_of_medicine": time,
        "room_no": room,
        "bed_no": bed,
        "patient_code": code
    }
    
    Pcode = patient_info['patient_code']
    
    generate_QRcode(patient_info, Pcode)

    # Load existing patient data from a JSON file if it exists
    try:
        with open("patient_data.json", "r") as file:
            data = json.load(file)
    except FileNotFoundError:
        data = []

    # Append the new patient information to the list
    data.append(patient_info)

    # Save the updated patient data back to the JSON file
    with open("patient_data.json", "w") as file:
        json.dump(data, file, indent=4)

    print("Patient checked in successfully!")

