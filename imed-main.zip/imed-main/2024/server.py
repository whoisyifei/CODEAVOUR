### System 1: Main Server with Database & API
# Run this on a laptop/PC as the central database
from flask import Flask, request, jsonify
import sqlite3
import datetime

app = Flask(__name__)

# Database Initialization
def init_db():
    conn = sqlite3.connect('medication.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS patients (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    age INTEGER,
                    height REAL,
                    weight REAL,
                    medication TEXT,
                    time TEXT,
                    bed_no TEXT,
                    room_no TEXT,
                    floor_no TEXT)''')
    conn.commit()
    conn.close()

init_db()

# Add new patient data
@app.route('/add_patient', methods=['POST'])
def add_patient():
    data = request.json
    conn = sqlite3.connect('medication.db')
    c = conn.cursor()
    c.execute("INSERT INTO patients (name, age, height, weight, medication, time, bed_no, room_no, floor_no) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
              (data['name'], data['age'], data['height'], data['weight'], data['medication'], data['time'], data['bed_no'], data['room_no'], data['floor_no']))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Patient added successfully'})

# Update patient data
@app.route('/update_patient/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    data = request.json
    conn = sqlite3.connect('medication.db')
    c = conn.cursor()
    c.execute("UPDATE patients SET name = ?, age = ?, height = ?, weight = ?, medication = ?, time = ?, bed_no = ?, room_no = ?, floor_no = ? WHERE id = ?",
              (data['name'], data['age'], data['height'], data['weight'], data['medication'], data['time'], data['bed_no'], data['room_no'], data['floor_no'], patient_id))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Patient updated successfully'})

# Get current medication schedule
@app.route('/get_schedule', methods=['GET'])
def get_schedule():
    now = datetime.datetime.now().strftime("%H:%M")
    conn = sqlite3.connect('medication.db')
    c = conn.cursor()
    c.execute("SELECT * FROM patients WHERE time = ?", (now,))
    patients = c.fetchall()
    conn.close()
    return jsonify(patients)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)