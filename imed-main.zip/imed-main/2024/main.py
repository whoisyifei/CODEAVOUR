#-change
from QR_gen import check_in_patient

from motor_control import motorPos
from cameraPi import StartCamera
from pynput.keyboard import Key, Listener
from time import sleep
import json
import sys
import firebase_admin
from firebase_admin import db
from firebase_admin import credentials

print("Initiating System...")
cred = credentials.Certificate(r"/home/pi/IMEDV3/fbKey/imed-5b179-firebase-adminsdk-419n5-d2f2b0c3f4.json")
firebase_admin.initialize_app(cred,{
    "databaseURL":"https://imed-5b179-default-rtdb.asia-southeast1.firebasedatabase.app/"
})
users_ref = db.reference('medical log/patients/ID')
sleep(1)
print("installing modules...")
sleep(2)
print("setup completed")
sleep(1)

def main():
    while True:
        main_menu()

def main_menu():
    print("------------------------------------")
    print("i. Initiate Camera Preview")
    print("q. Exit\n")
    
    command = str(input("Enter a command: "))
        
    if command == "i":
        print("Starting Camera ePreview...")
        db = users_ref.get()
        sleep(1)
        d=StartCamera()
        print(d)
        Data = db[d]
        
        pos = Data['medications']
        
        for i in pos:
            x = pos.get(i)
            if x!=0:
                print(i)
                print(x)
                motorPos(i, x)
            
    elif command == "q":
        sys.exit(0)
    else:
        print("Invalid Command!")

main()
#--remove
#data = {'age': 0, 'bed_number': '1', 'date_of_birth': '23/4/2024', 'full_name': 'Hii Zan Yi', 'medications': {'Panadol': 1, 'Paracetamol': 4, 'Penicillin': 1, 'Vicodin': 0, 'Vitamin C': 6, 'Vitamin D': 6, 'Vitamin E': 20}}
#pos = medicine = data['medications']
#for i in pos:
#    x = pos.get(i)
#    print(i)
#    print(x)
#    motorPos(i, x)
