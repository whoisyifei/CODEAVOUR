# --------------------- Modules ----->
from picamera import PiCamera
from picamera.array import PiRGBArray
from pyzbar.pyzbar import decode
import ast

# --------------------- Functions ----->
# Function to start the camera preview
def start_camera_preview():
    camera = PiCamera()
    camera.resolution = (1024, 768)
    camera.start_preview(fullscreen=False, window=(1250, 580, 640, 480))
    return camera

# Function to stop the camera preview
def stop_camera_preview(camera):
    camera.stop_preview()
    camera.close()

def StartCamera():
    try:
        camera = start_camera_preview()
        raw_capture = PiRGBArray(camera)
        for frame in camera.capture_continuous(raw_capture, format="bgr", use_video_port=True):
            # Retrieve the image as a NumPy array
            image = frame.array

            # Decode QR codes in the image
            decoded_objects = decode(image)
            # Process detected QR codes
            for obj in decoded_objects:
                data = obj.data.decode("utf-8")
#                 data_dict = ast.literal_eval(data)
#                 updatedData = json.loads(data)
                
                return data

            # Clear the PiRGBArray for the next frame
            raw_capture.truncate(0)

    except KeyboardInterrupt:
        print("Program terminated by user.")
        
    finally:
        stop_camera_preview(camera)
