# --------------------- Modules ----->
from step_motor import StepAFor, StepABack, StepBFor, StepBBack
import RPi.GPIO as GPIO
from time import sleep

# --------------------- Setup ----->

# --------------------- Functions ----->
def MotorA(DIR, num):
    i = 0
    print("-- log 1 --")
    if DIR == True:
        while i < num:
            print(i)
            StepAFor(150)
            sleep(0.5)
            StepABack(150)
            sleep(0.5)
            i += 1
        
    if DIR == False:
        while i < num:
            print(i)
            StepABack(150)
            sleep(0.5)
            StepAFor(150)
            sleep(0.5)
            i += 1

def MotorControl(STEPS, DIR, num):
    print(STEPS)
    print(DIR)
    print(num)
    print("Starting...")
    print("Running Stepper Forward...")
    StepBFor(STEPS)
    sleep(0.5)
    print("Running Servo...")
    MotorA(DIR, num)
    sleep(0.5)
    print("Running Stepper Backward...")
    STEPS = STEPS + 10
    StepBBack(STEPS)
    print("Closing...")

def motorPos(typ, num):
    STEPS = 0
    a, b = 210, 210
    c, d = 440, 440
    e, f = 650, 650
    g, h = 450, 450
    i, j = 600, 600
    k, l = 750, 750
    m, n = 900, 900
    
    if typ.lower() == "paracetamol":
        STEPS = a
        DIR = False
    elif typ.lower() == "penicillin":
        STEPS = c
        DIR = False
    elif typ.lower() == "vitamin c":
        STEPS = e
        DIR = False
    elif typ.lower() == "vitamin d":
        STEPS = b
        DIR = True
    elif typ.lower() == "vitamin e":
        STEPS = d
        DIR = False
    elif typ.lower() == "panadol":
        STEPS = f
        DIR = True
    elif typ.lower() == "vicodin":
        STEPS = g
        DIR = False
    elif typ.lower() == "h":
        STEPS = h
        DIR = True
    elif typ.lower() == "i":
        STEPS = i
        DIR = False
    elif typ.lower() == "j":
        STEPS = j
        DIR = True
    elif typ.lower() == "k":
        STEPS = k
        DIR = False
    elif typ.lower() == "l":
        STEPS = l
        DIR = True
    elif typ.lower() == "m":
        STEPS = m
        DIR = False
    elif typ.lower() == "n":
        STEPS = n
        DIR = True
    else:
        STEPS = 0
        DIR = False
    
    MotorControl(STEPS, DIR, num)
