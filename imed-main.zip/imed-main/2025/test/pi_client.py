import buzzer_control
import time

SERVER_URL = "http://172.24.57.53:5000"  # Replace with your Flask server IP

def check_underage_users():
    try:
        response = buzzer_control.get(f"{SERVER_URL}/underage")
        if response.status_code == 200:
            underage_users = response.json()
            if underage_users:
                for user in underage_users:
                    print(f"UNDER AGE: {user['name']} (Age: {user['age']})")
            else:
                print("No underage users found")
        else:
            print("Error fetching data from server")
    except buzzer_control.exceptions.RequestException as e:
        print(f"Connection error: {e}")

if __name__ == "__main__":
    print("Starting underage user monitor...")
    while True:
        check_underage_users()
        time.sleep(10)  # Check every 10 seconds