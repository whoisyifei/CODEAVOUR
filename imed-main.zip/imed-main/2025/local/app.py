from flask import Flask, request, jsonify, send_file
from models import db, Patient, Schedule, BiometricLog
from flask_cors import CORS
from datetime import time as dtime 
from datetime import datetime
import qrcode
import os

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://imed:imed@localhost/patientdb'
db.init_app(app)

@app.route('/patients', methods=['GET'])
def get_patients():
    patients = Patient.query.all()
    result = []
    for p in patients:
        has_schedule = Schedule.query.filter_by(patient_id=p.id).first()
        serialized = p.serialize()
        serialized['schedule'] = 'scheduled' if has_schedule else 'not scheduled'
        result.append(serialized)
    return jsonify(result)

@app.route('/admit', methods=['POST'])
def admit_patient():
    data = request.json
    patient = Patient(**data)
    db.session.add(patient)
    db.session.commit()

    # Generate QR code with patient ID and name
    qr_data = f"{patient.id}|{patient.name}"
    img = qrcode.make(qr_data)
    qr_path = f"qrcodes/patient_{patient.id}.png"
    os.makedirs(os.path.dirname(qr_path), exist_ok=True)
    img.save(qr_path)

    return jsonify({'status': 'admitted', 'qr_code': qr_path})

@app.route('/biometric', methods=['POST'])
def log_biometric():
    data = request.json
    entry = BiometricLog(**data)
    db.session.add(entry)
    db.session.commit()
    return jsonify({'status': 'logged'})

@app.route('/schedule/all', methods=['GET'])
def get_all_schedules():
    schedule = Schedule.query.all()
    return jsonify([s.serialize() for s in schedule])

@app.route('/schedule', methods=['POST'])
def add_schedule():
    data = request.json
    patient = Patient.query.get(data['patient_id'])
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404

    # Parse time string like "08:30:00"
    try:
        scheduled_time = datetime.strptime(data['time'], "%H:%M:%S").time()
    except ValueError:
        return jsonify({'error': 'Time format must be HH:MM:SS'}), 400

    schedule = Schedule(
        patient_id=data['patient_id'],
        time=scheduled_time,
        task=data['task']
    )
    db.session.add(schedule)
    db.session.commit()
    return jsonify({'status': 'scheduled'})

@app.route('/schedule/<int:patient_id>', methods=['PUT'])
def update_schedule(patient_id):
    data = request.json
    patient = Patient.query.get(patient_id)
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404

    # Get the first schedule entry for the patient
    schedule = Schedule.query.filter_by(patient_id=patient_id).first()
    if not schedule:
        return jsonify({'error': 'No schedule found for this patient'}), 404

    if 'time' in data:
        try:
            schedule.time = datetime.strptime(data['time'], "%H:%M:%S").time()
        except ValueError:
            return jsonify({'error': 'Time format must be HH:MM:SS'}), 400

    if 'task' in data:
        schedule.task = data['task']

    db.session.commit()
    return jsonify({'status': 'schedule updated'})

@app.route('/patients/<int:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)

    # Delete related biometric logs
    BiometricLog.query.filter_by(patient_id=patient_id).delete()

    # Delete related schedules
    Schedule.query.filter_by(patient_id=patient_id).delete()

    # Delete patient
    db.session.delete(patient)
    db.session.commit()
    return jsonify({'status': 'deleted'})

@app.route('/prescription/<int:patient_id>', methods=['GET'])
def get_prescription(patient_id):
    patient = db.session.get(Patient, patient_id)
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404

    # Split prescriptions by comma if stored as a single string
    meds = [med.strip() for med in patient.prescriptions.split(",")] if patient.prescriptions else []
    return jsonify({'medications': meds})

if __name__ == '__main__':
    # Ensure the tables are created within the app context
    with app.app_context():
        db.create_all()  # This will create the necessary tables in the database if not already created
    app.run(host='0.0.0.0', port=5000)


# /admit (POST)
# {
#   "name": "John Doe",
#   "status": "admitted",
#   "diagnostics": "High blood pressure",
#   "prescriptions": "Metformin",
#   "room_number": "A101"
# }


# /schedule (POST)
# {
#   "patient_id": ,
#   "time": "00:00:00",
#   "task": "dispense"
# }

# /schedule/1 (PUT)
# {
#   "time": "14:25:00",
#   "task": "dispense"
# }

# /patients (GET)
# Returns a list of all patients with their schedules status

#/patients/1 (DELETE)
# Deletes patient with ID 1 and all related biometric logs and schedules

# /schedule/all (GET)
# Returns all schedules
