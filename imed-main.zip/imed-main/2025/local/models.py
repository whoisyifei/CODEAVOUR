from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy import Time

db = SQLAlchemy()

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    status = db.Column(db.String(50))  # admitted, discharged
    diagnostics = db.Column(db.Text)
    prescriptions = db.Column(db.Text)
    room_number = db.Column(db.String(10))

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'status': self.status,
            'diagnostics': self.diagnostics,
            'prescriptions': self.prescriptions,
            'room_number': self.room_number
        }

class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'))
    time = db.Column(Time)
    task = db.Column(db.String(100))

    patient = db.relationship("Patient", backref="schedules", lazy="joined")

    def serialize(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "patient_name": self.patient.name if self.patient else None,  # NEW
            "time": self.time.isoformat() if self.time else None,
            "task": self.task,
        }


class BiometricLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    temperature = db.Column(db.Float)
    heart_rate = db.Column(db.Integer)
    spo2 = db.Column(db.Float)
    anomaly_flag = db.Column(db.Boolean, default=False)

    def serialize(self):
        return {
            'id': self.id,
            'patient_id': self.patient_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'temperature': self.temperature,
            'heart_rate': self.heart_rate,
            'spo2': self.spo2,
            'anomaly_flag': self.anomaly_flag
        }
