import time, cv2, json
from pyzbar.pyzbar import decode
from picamera2 import Picamera2


# ────────────────────────────────────────────────────────────────
# 1)  Parse a QR payload  →  (patient_name, patient_id)
# ────────────────────────────────────────────────────────────────
def parse_patient_id(payload: str):
    payload = payload.strip()

    # "12345,John Doe"  (comma-separated)
    if "|" in payload:
        patient_id, patient = payload.split("|", 1)
        return patient.strip(), patient_id.strip()

    # {"id":12345,"name":"John Doe"}  (JSON)
    try:
        obj = json.loads(payload)
        print(str(obj["name"]), str(obj["id"]))
        return str(obj["name"]), str(obj["id"])
    except Exception:
        return None, None


# ────────────────────────────────────────────────────────────────
# 2)  Scan until a QR code is found, then return (patient, id)
# ────────────────────────────────────────────────────────────────
def scan_patient_qr(window_title="Pi Camera QR Scanner"):
    """
    Opens the Pi Camera, scans frames, prints the decoded
    payload, and returns (patient_name, patient_id) when found.
    """
    picam2 = Picamera2()
    config = picam2.create_preview_configuration(main={"size": (640, 480)})
    picam2.configure(config)
    picam2.start()
    time.sleep(2)

    last_data = None

    try:
        while True:
            frame = picam2.capture_array()

            for obj in decode(frame):
                raw = obj.data.decode("utf-8")

                # Skip duplicates on successive frames
                if raw == last_data:
                    continue
                last_data = raw

                # --- PRINT the raw payload ---
                print(f"🔍  Raw QR data: {raw}")

                patient, patient_id = parse_patient_id(raw)
                if patient and patient_id:
                    # --- PRINT the parsed fields ---
                    print(f"✅  Patient: {patient} | ID: {patient_id}")

                    # Optional on-screen overlay
                    x, y, w, h = obj.rect
                    cv2.rectangle(frame, (x, y), (x + w, y + h),
                                  (0, 255, 0), 2)
                    cv2.putText(frame, f"{patient} ({patient_id})",
                                (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX,
                                0.6, (255, 0, 0), 2)
                    cv2.imshow(window_title, frame)
                    cv2.waitKey(500)            # flash overlay ½ sec
                    return patient, patient_id  # ←────────── result!

            cv2.imshow(window_title, frame)
            cv2.waitKey(1)                    # keep GUI responsive

    finally:
        picam2.stop()
        cv2.destroyAllWindows()
