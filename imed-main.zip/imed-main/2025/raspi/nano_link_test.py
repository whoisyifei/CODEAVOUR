import serial, time

ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
time.sleep(2)  # give Nano time to reset
print("Connected to Maker Nano\n")

try:
    while True:
        line = ser.readline().decode('utf-8', errors='ignore').strip()
        if line:
            print("Received:", line)
except KeyboardInterrupt:
    print("\nStopped")
finally:
    ser.close()
