# shared_state.py

from collections import deque

CURRENT_TASK = None
CURRENT_TEMPERATURE = 0.0
CURRENT_WEIGHT = 0.0

# Log storage list, capped at 100 entries.
LOG_ENTRIES = deque(maxlen=100)