import time
from datetime import datetime, timedelta
from aruco import detect_marker_positions
from server import get_all_schedules, get_patient_prescription, is_within_time_window
from step_motor import move_to_position, set_direction, origin
from camera import scan_patient_qr
from cryptography.fernet import Fernet

# Load encryption key from file (only once)
with open("encryption.key", "rb") as key_file:
    ENCRYPTION_KEY = key_file.read()

cipher = Fernet(ENCRYPTION_KEY)

def encrypt(data: str) -> str:
    return cipher.encrypt(data.encode()).decode()

def decrypt(token: str) -> str:
    return cipher.decrypt(token.encode()).decode()

# ========================
# 📦 Medication Map
# ========================

# Map of medication names to ArUco IDs
medication_map = {
    1: "Paracetamol", 2: "Ibuprofen", 3: "Aspirin", 4: "Amoxicillin",
    5: "Cetirizine", 6: "Metformin", 7: "Omeprazole", 8: "Loperamide",
    9: "Hydroxyzine", 10: "Clindamycin", 11: "Prednisone", 12: "Diphenhydramine",
    13: "Azithromycin", 14: "Simvastatin", 15: "Atorvastatin", 16: "Salbutamol"
}

# Dictionary to store last dispense times per patient
recently_dispensed = {}

# Dispense cooldown window (5 minutes)
DISPENSE_WINDOW = timedelta(minutes=5)

# ========================
# 🏁 Main Program
# ========================

if __name__ == "__main__":
    marker_positions = detect_marker_positions()
    set_direction(True)

    while True:
        print("\n📅 Checking schedules...\n")
        schedules = get_all_schedules()

        if not schedules:
            print("[INFO] No schedules found.")
        else:
            print(f"[INFO] {len(schedules)} schedule(s) retrieved from server.")

        for task in schedules:
            print("DEBUG raw task →", task)

            name = task.get("patient_name")
            patient_id = task.get("patient_id")
            scheduled_time = task.get("time")  # ISO format
            task_type = task.get("task")

            meds = get_patient_prescription(patient_id)

            # Encrypt patient data for logging
            enc_name = encrypt(name)
            enc_id = encrypt(str(patient_id))
            enc_meds = [encrypt(med) for med in meds] if meds else []

            print(f"\n🧾 Encrypted Patient Name: {enc_name}")
            print(f"🧾 Encrypted Patient ID: {enc_id}")
            print(f"📌 Task: {task_type}")
            print(f"🕒 Scheduled Time: {scheduled_time}")
            print(f"💊 Encrypted Medications: {enc_meds if meds else 'None'}")

            now = datetime.now()

            if task_type == "dispense" and is_within_time_window(scheduled_time):
                last_dispensed = recently_dispensed.get(patient_id)

                if last_dispensed and (now - last_dispensed) < DISPENSE_WINDOW:
                    print(f"⏳ Patient {patient_id} already dispensed at {last_dispensed.strftime('%H:%M:%S')}. Skipping.")
                    continue  # Skip to next schedule

                print(f"\n[TRIGGER] It's time to dispense for Patient {patient_id}!\n")

                # Scan patient QR
                patient, pid = scan_patient_qr()

                # Match scanned patient with scheduled patient (using decrypted comparison)
                if str(patient_id) == str(pid) and name.strip().lower() == patient.strip().lower():
                    for med in meds:
                        marker_id = next((mid for mid, med_name in medication_map.items() if med_name == med), None)
                        if marker_id and marker_id in marker_positions:
                            row, col = marker_positions[marker_id]
                            print(f"🔄 Moving to dispense {med} at {row}-{col}")
                            move_to_position(col)
                        else:
                            print(f"⚠️ Medication '{med}' not found in detected markers.")

                    # Return to origin after dispensing
                    origin()
                    recently_dispensed[patient_id] = now
                    print(f"📝 Dispense recorded for Patient {patient_id} at {now.strftime('%H:%M:%S')}")
                else:
                    print("❌ Patient scan mismatch. Skipping dispense.")

        time.sleep(60)

