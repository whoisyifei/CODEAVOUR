from datetime import datetime
from typing import List, Dict

# Maximum number of log entries to store
MAX_LOG_ENTRIES = 100

# Global list to hold log entries
# Each entry is a dictionary: {"timestamp": "...", "level": "INFO/ERROR/WARN", "message": "..."}
ROBOT_LOGS: List[Dict] = []

def add_log_entry(level: str, message: str):
    """
    Adds a new log entry to the ROBOT_LOGS list and prunes older entries.
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_log = {
        "timestamp": now,
        "level": level.upper(),
        "message": message
    }
    # Add to the beginning of the list (newest first)
    ROBOT_LOGS.insert(0, new_log)

    # Prune old logs to maintain MAX_LOG_ENTRIES
    if len(ROBOT_LOGS) > MAX_LOG_ENTRIES:
        ROBOT_LOGS.pop() # Remove oldest entry (last element)

def get_logs() -> List[Dict]:
    """
    Returns the current list of robot logs.
    """
    return ROBOT_LOGS

# Example entries for initial startup
add_log_entry("INFO", "Application initialization started.")
add_log_entry("INFO", "Configuration loaded successfully.")
add_log_entry("WARN", "Database connection established with low latency.")