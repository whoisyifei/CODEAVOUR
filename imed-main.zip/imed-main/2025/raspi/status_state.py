from datetime import datetime

# --- GLOBAL STATE VARIABLES ---

# 1. Overall Startup Status (used for the initial system monitor)
CURRENT_STATUS = [
    # FIX: Cleaned up indentation to remove SyntaxError: invalid non-printable character U+00A0
    {"stage": "INITIALIZING", "message": "System starting up...", "is_complete": False, "timestamp": None},
    {"stage": "API_SERVER", "message": "Starting Flask API server...", "is_complete": False, "timestamp": None},
    {"stage": "ROBOT_CORE", "message": "Initializing Robot Control Loop...", "is_complete": False, "timestamp": None},
]

# 2. Current Active Robot Task (used by the /api/task endpoint and TaskProgress component)
# This will hold a dict (e.g., {"task_id": "T123", "patient_name": "...", "current_stage": "MOVING"}) or None.
CURRENT_TASK_STATE = None

# --- HELPER FUNCTIONS ---

def update_status_stage(stage_name, message_override=None, is_complete=False):
    """
    Updates a specific stage in the CURRENT_STATUS list (for startup monitor).
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for stage in CURRENT_STATUS:
        if stage["stage"] == stage_name:
            if message_override is not None:
                stage["message"] = message_override
            stage["is_complete"] = is_complete
            stage["timestamp"] = now
            return

def set_current_task_state(task_state: dict):
    """
    Sets the detailed state for the currently executing robot task.
    """
    global CURRENT_TASK_STATE
    CURRENT_TASK_STATE = task_state

def update_task_stage(new_stage: str, message: str = None):
    """
    Updates the current stage of the active robot task.
    """
    global CURRENT_TASK_STATE
    if CURRENT_TASK_STATE is not None:
        CURRENT_TASK_STATE["current_stage"] = new_stage
        if message:
            CURRENT_TASK_STATE["message"] = message

def reset_task_state():
    """
    Resets the task state back to IDLE (None), signaling no task is running.
    """
    global CURRENT_TASK_STATE
    CURRENT_TASK_STATE = None