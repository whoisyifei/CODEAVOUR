# generate_key.py

from cryptography.fernet import Fernet

key = Fernet.generate_key()  # Generates a proper 32-byte key, base64 encoded

with open("encryption.key", "wb") as key_file:
    key_file.write(key)

print("✅ Fernet encryption.key successfully created.")
