import subprocess
import threading
import time
import os
import webbrowser

# --- Execution Setup ---

FLASK_SERVER_COMMAND = ["python3", "log_api.py"]
MAIN_LOOP_COMMAND = ["python3", "main.py"]

# === FIX HERE: Change APP_URL to the reliable local loopback address ===
APP_URL = "http://127.0.0.1:5000"
# ======================================================================

WAIT_TIME = 5 # seconds to wait for server to start

def run_process(command, name):
    """Runs a process and prints its output in a separate thread."""
    print(f"[{name}] Starting process: {' '.join(command)}")
    try:
        # Use subprocess.run for simpler execution without managing stdout/stderr streams
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] {name} process failed with exit code {e.returncode}")
    except FileNotFoundError:
        print(f"[ERROR] Could not find python3 or {command[1]}. Ensure all files are present.")
    finally:
        print(f"[{name}] Process finished.")

def launch_application():
    """Launches the backend server and frontend in separate threads, then opens the browser."""
    
    print("--- Starting IMED Application ---")
    
    # 1. Start Flask Server (Web UI + API)
    print("[SERVER] Attempting to start Flask server...")
    
    server_thread = threading.Thread(target=run_process, args=(FLASK_SERVER_COMMAND, "SERVER"))
    server_thread.daemon = True # Allows program to exit even if thread is running
    server_thread.start()
    
    # 2. Wait for server to initialize
    print(f"[SYSTEM] Waiting {WAIT_TIME} seconds for the server to start...")
    time.sleep(WAIT_TIME)
    
    # 3. Start Main Robot Logic Loop (Hardware control)
    print("[ROBOT] Starting main robot control loop...")
    robot_thread = threading.Thread(target=run_process, args=(MAIN_LOOP_COMMAND, "ROBOT_CORE"))
    robot_thread.daemon = True 
    robot_thread.start()
    
    # 4. Launch Frontend UI in Web Browser
    print(f"[BROWSER] Opening application UI at {APP_URL}")
    try:
        webbrowser.open(APP_URL, new=2, autoraise=True)
    except Exception as e:
        print(f"[WARNING] Could not automatically open web browser: {e}")
        print(f"Please manually navigate to: {APP_URL}")

    # 5. Keep the main thread alive until threads finish (or manually stopped)
    print("\n[SYSTEM] Application is running. Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[SYSTEM] Stopping application...")
    finally:
        print("--- IMED Application Shut Down ---")

if __name__ == "__main__":
    launch_application()