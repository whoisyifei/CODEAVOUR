import threading
from app_server import app  # Imports the Flask app
from main import run_main_loop  # Imports your main loop function

if __name__ == "__main__":
    print("Starting main application loop in a separate thread...")
    # Start the main.py logic in a background thread
    # daemon=True means the thread will close when the server stops
    main_thread = threading.Thread(target=run_main_loop, daemon=True)
    main_thread.start()
    
    print("Starting Flask server for React frontend...")
    # Start the Flask server in the main thread
    # Run on 0.0.0.0 to be accessible from your network
    app.run(host="0.0.0.0", port=8000)