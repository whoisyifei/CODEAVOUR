import time
import board
import digitalio
from adafruit_motor import stepper

# Motor pins
coils = (
    digitalio.DigitalInOut(board.D16),
    digitalio.DigitalInOut(board.D25),
    digitalio.DigitalInOut(board.D23),
    digitalio.DigitalInOut(board.D24),
)
coilsB = (
    digitalio.DigitalInOut(board.D18),
    digitalio.DigitalInOut(board.D17),
    digitalio.DigitalInOut(board.D27),
    digitalio.DigitalInOut(board.D22),
)

for c in coils + coilsB:
    c.direction = digitalio.Direction.OUTPUT

motor = stepper.StepperMotor(*coils, microsteps=None)
motorB = stepper.StepperMotor(*coilsB, microsteps=None)

# Motor constants
STEPS_PER_REV = 200
ROD_PITCH = 2.0
STEPS_PER_MM = STEPS_PER_REV / ROD_PITCH
POSITIONS = {chr(ord('A') + i): i * 10.0 for i in range(8)}  # A–H → 0–70mm
current_pos_mm = 0.0
forward = True

def move_stepper(steps):
    direction = stepper.FORWARD if steps > 0 else stepper.BACKWARD
    steps = abs(steps)
    for _ in range(steps):
        motor.onestep(direction=direction)
        time.sleep(0.001)
    motor.release()

def StepB():
    global forward
    steps = 3000
    dir1 = stepper.FORWARD if forward else stepper.BACKWARD
    dir2 = stepper.BACKWARD if forward else stepper.FORWARD
    for _ in range(steps):
        motorB.onestep(direction=dir1)
        time.sleep(0.001)
    motorB.release()
    time.sleep(0.5)
    for _ in range(steps):
        motorB.onestep(direction=dir2)
        time.sleep(0.001)
    motorB.release()

def move_to_position(col_letter):
    global current_pos_mm
    if col_letter not in POSITIONS:
        print(f"[ERROR] Invalid position {col_letter}")
        return
    target_mm = POSITIONS[col_letter]
    steps = int(round((target_mm - current_pos_mm) * STEPS_PER_MM))
    move_stepper(steps)
    current_pos_mm = target_mm
    StepB()

def set_direction(is_forward):
    global forward
    forward = is_forward

def origin():
    global current_pos_mm
    target_mm = POSITIONS["A"]
    steps = int(round((target_mm - current_pos_mm) * STEPS_PER_MM))
    move_stepper(steps)
    current_pos_mm = target_mm
