import requests
from datetime import datetime, timedelta

SERVER_URL = "http://192.168.178.30:5000"
TIME_MARGIN_MINUTES = 5

def get_all_schedules():
    try:
        resp = requests.get(f"{SERVER_URL}/schedule/all")
        return resp.json() if resp.status_code == 200 else []
    except Exception as e:
        print("[ERROR] Fetching schedules failed:", e)
        return []

def get_patient_prescription(patient_id):
    try:
        resp = requests.get(f"{SERVER_URL}/prescription/{patient_id}")
        print(f"[DEBUG] Prescription raw response: {resp.text}")
        if resp.status_code == 200:
            data = resp.json()
            meds = data.get("medications")
            print(f"[DEBUG] Extracted medications: {meds}")  # Optional
            return meds  # Don't wrap in another get()
        return []
    except Exception as e:
        print("[ERROR] Getting prescription:", e)
        return []



def is_within_time_window(scheduled_time_str):
    try:
        now = datetime.now().time()
        scheduled_time = datetime.strptime(scheduled_time_str, "%H:%M:%S").time()
        now_dt = datetime.combine(datetime.today(), now)
        sched_dt = datetime.combine(datetime.today(), scheduled_time)
        delta = abs(now_dt - sched_dt)
        if delta <= timedelta(minutes=TIME_MARGIN_MINUTES):
            print("Time Margin 101")
        return delta <= timedelta(minutes=TIME_MARGIN_MINUTES)
    except Exception as e:
        print("[ERROR] Time check failed:", e)
        return False

