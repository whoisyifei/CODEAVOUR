# This file holds data that is shared between main.py and app_server.py
# This is NOT a class, just a module with global variables.

CURRENT_TASK = None
CURRENT_TEMPERATURE = "-"
CURRENT_WEIGHT = "-"
SYSTEM_STATS = {"cpu": 0, "memory": 0, "disk": 0}