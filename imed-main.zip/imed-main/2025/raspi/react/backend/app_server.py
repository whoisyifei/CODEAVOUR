from flask import Flask, request, jsonify
from flask_cors import CORS
import psutil
import os
import shared_state # Import the shared state

app = Flask(__name__)
CORS(app) # Allow React app to talk to this server

# --- These functions read from the shared state ---

def get_temperature():
    # Reads from the global state updated by main.py
    return shared_state.CURRENT_TEMPERATURE

def get_weight():
    # Reads from the global state updated by main.py
    return shared_state.CURRENT_WEIGHT

def get_folders():
    # TODO: Update this path to your folder
    path = "." # Checks the current directory
    if not os.path.exists(path):
        return []
    try:
        # Returns all files in the directory
        return [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
    except Exception as e:
        print(f"Error reading folders: {e}")
        return []
    
def get_system_stats():
    # Gets live system stats on demand
    try:
        shared_state.SYSTEM_STATS = {
            "cpu": psutil.cpu_percent(),
            "memory": psutil.virtual_memory().percent,
            "disk": psutil.disk_usage('/').percent
        }
    except Exception as e:
        print(f"Error getting system stats: {e}")
    return shared_state.SYSTEM_STATS
    
def get_current_task_status():
    # Reads from the global state updated by main.py
    # This is what React will poll for the progress display
    return shared_state.CURRENT_TASK

# This is the "router" that React calls
function_map = {
    "get_temperature": get_temperature,
    "get_weight": get_weight,
    "get_folders": get_folders,
    "get_system_stats": get_system_stats,
    "get_current_task_status": get_current_task_status,
}

@app.route("/execute", methods=["POST"])
def execute():
    data = request.json
    function_name = data.get("function")
    
    if function_name in function_map:
        try:
            result = function_map[function_name]()
            return jsonify({"result": result})
        except Exception as e:
            print(f"Error executing {function_name}: {e}")
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Function not found"}), 404

# This part is removed because run.py handles starting the app
# if __name__ == "__main__":
#     app.run(host="0.0.0.0", port=8000)