import React, { useState, useEffect } from "react";
import { FaHdd, FaMemory, FaMicrochip } from 'react-icons/fa';
import { useAppContext } from '../context/AppContext';
import { StatBar } from '../components/StatBar';

export default function SystemScreen() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const { serverIp } = useAppContext(); // Get server IP from context

  const fetchStats = () => {
    setLoading(true);
    fetch(`${serverIp}/execute`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ function: "get_system_stats" }),
    })
      .then((res) => res.json())
      .then((j) => {
        if (j.result && typeof j.result === 'object') {
          setStats(j.result);
        } else {
          setStats(null);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch stats:", err);
        setLoading(false);
        setStats(null);
      });
  };

  useEffect(() => {
    fetchStats();
  }, [serverIp]); // Re-fetch if server IP changes

  return (
    <div className="system-container">
      <div className="system-header">
        <h1 className="system-title">System Monitor</h1>
        <button onClick={fetchStats} className="check-button">
          Refresh
        </button>
      </div>
      <div className="stat-list">
        {loading && <div style={{ color: "#9EB3C2" }}>Loading stats...</div>}
        {!loading && !stats && (
          <div style={{ color: "#E57373" }}>Failed to load system stats.</div>
        )}
        {!loading && stats && (
          <>
            <StatBar icon={<FaMicrochip />} label="CPU Usage" value={stats.cpu} />
            <StatBar icon={<FaMemory />} label="Memory Usage" value={stats.memory} />
            <StatBar icon={<FaHdd />} label="Disk Usage" value={stats.disk} />
          </>
        )}
      </div>
    </div>
  );
}