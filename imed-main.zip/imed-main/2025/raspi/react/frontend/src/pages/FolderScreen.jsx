import React, { useState, useEffect } from "react";
import { FaFolder } from 'react-icons/fa';
import { useAppContext } from '../context/AppContext';

export default function FolderScreen() {
  const [folders, setFolders] = useState([]);
  const [loading, setLoading] = useState(true);
  const { serverIp } = useAppContext(); // Get server IP from context

  useEffect(() => {
    setLoading(true);
    fetch(`${serverIp}/execute`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ function: "get_folders" }),
    })
      .then((res) => res.json())
      .then((j) => {
        if (Array.isArray(j.result)) {
          setFolders(j.result);
        } else {
          setFolders([]);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch folders:", err);
        setLoading(false);
      });
  }, [serverIp]); // Re-fetch if server IP changes

  return (
    <div className="folder-container">
      <h1 className="folder-title">Folders</h1>
      <div className="folder-list">
        {loading && <div style={{ color: "#9EB3C2" }}>Loading folders...</div>}
        {!loading && folders.length === 0 && (
          <div style={{ color: "#9EB3C2" }}>No folders found.</div>
        )}
        {!loading &&
          folders.map((folderName) => (
            <FolderRow key={folderName} name={folderName} />
          ))}
      </div>
    </div>
  );
}

function FolderRow({ name }) {
  return (
    <div className="folder-row">
      <div className="folder-icon-box">
        <FaFolder />
      </div>
      <span className="folder-name">{name}</span>
    </div>
  );
}