import React, { useState } from "react";
import { FaCamera, FaWifi, FaThermometerHalf, FaWeightHanging, FaBox, FaLightbulb, FaFan } from 'react-icons/fa';
import { useAppContext } from '../context/AppContext';
import { GraphDisplay } from '../components/GraphDisplay';
import { ProgressDisplay } from '../components/ProgressDisplay';
import { StatusCard } from '../components/StatusCard';

export default function HomeScreen() {
  // Get all state from the global context
  const { isConnected, temperature, weight, tempHistory, currentTask } = useAppContext();
  const [medStatus] = useState("-"); // This can be moved to context later if needed

  return (
    <div className="home-layout">
      <div className="left-panel">
        <div className="top-row">
          <span style={{ fontSize: 20, opacity: 0.7 }}>°C</span>
          <div className="top-icons">
            <FaCamera size={22} color="#9EB3C2" />
            <FaWifi size={22} color={isConnected ? "#9EB3C2" : "#E57373"} />
          </div>
        </div>
        
        {/* === NEW: Conditional Rendering === */}
        {currentTask ? (
          <ProgressDisplay task={currentTask} />
        ) : (
          <GraphDisplay data={tempHistory} />
        )}

      </div>

      <div className="right-panel">
        <h1 className="title">IMED</h1>
        <StatusCard
          icon={<FaThermometerHalf size={24} />}
          value={`${temperature}`}
        />
        <StatusCard
          icon={<FaWeightHanging size={24} />}
          value={`${weight}`}
        />
        <StatusCard icon={<FaBox size={24} />} value={medStatus} />
        <div className="bottom-buttons">
          <div className="circle-button">
            <FaLightbulb />
          </div>
          <div className="circle-button">
            <FaFan />
          </div>
        </div>
      </div>
    </div>
  );
}