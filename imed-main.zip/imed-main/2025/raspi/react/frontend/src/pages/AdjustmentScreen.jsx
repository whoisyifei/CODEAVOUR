import React, { useState, useEffect } from "react";
import { FaThermometerHalf, FaWeightHanging, FaBox } from 'react-icons/fa';
import { useAppContext } from '../context/AppContext';

export default function AdjustmentScreen() {
  const [temperature, setTemperature] = useState("--");
  const [weight, setWeight] = useState("--");
  const [medStatus] = useState("--");
  const { serverIp } = useAppContext(); // Get server IP from context

  const checkTemperature = () => {
    setTemperature("Checking...");
    fetch(`${serverIp}/execute`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ function: "get_temperature" }),
    })
      .then((res) => res.json())
      .then((j) => setTemperature(j.result ?? "--"))
      .catch(() => setTemperature("Error"));
  };

  const checkWeight = () => {
    setWeight("Checking...");
    fetch(`${serverIp}/execute`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ function: "get_weight" }),
    })
      .then((res) => res.json())
      .then((j) => setWeight(j.result ?? "--"))
      .catch(() => setWeight("Error"));
  };

  useEffect(() => {
    checkTemperature();
    checkWeight();
  }, [serverIp]); // Re-check if server IP changes

  return (
    <div className="adjustment-container">
      <h1 className="adjustment-title">Adjustment</h1>
      <div className="adjustment-list">
        <AdjustmentRow
          icon={<FaThermometerHalf />}
          label="Temperature"
          value={`${temperature}`}
          onCheck={checkTemperature}
        />
        <AdjustmentRow
          icon={<FaWeightHanging />}
          label="Weight"
          value={`${weight}`}
          onCheck={checkWeight}
        />
        <AdjustmentRow
          icon={<FaBox />}
          label="Medication State"
          value={medStatus}
        />
      </div>
    </div>
  );
}

// This component is only used here, so it's fine to keep it in this file.
function AdjustmentRow({ icon, label, value, onCheck }) {
  return (
    <div className="adjustment-row">
      <div className="adjustment-row-info">
        <div className="adjustment-icon-box">{icon}</div>
        <div className="adjustment-row-text">
          <div className="adjustment-row-label">{label}</div>
          <div className="adjustment-row-value">{value}</div>
        </div>
      </div>
      <button
        onClick={onCheck}
        disabled={!onCheck}
        className={onCheck ? "check-button" : "check-button-disabled"}
      >
        Check
      </button>
    </div>
  );
}