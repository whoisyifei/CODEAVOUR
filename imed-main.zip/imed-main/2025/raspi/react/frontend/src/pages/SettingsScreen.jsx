import React, { useState } from "react";
import { useAppContext } from '../context/AppContext';

export default function SettingsScreen() {
  const { serverIp, updateServerIp } = useAppContext();
  const [tempIp, setTempIp] = useState(serverIp);

  const handleSave = () => {
    updateServerIp(tempIp);
    alert("Server IP saved!");
  };

  return (
    <div className="settings-container">
      <h1 className="settings-title">Settings</h1>
      <div className="settings-content">
        <div className="settings-input-group">
          <label className="settings-label">Server IP Address</label>
          <input 
            className="settings-input"
            type="text"
            value={tempIp}
            onChange={(e) => setTempIp(e.target.value)}
            placeholder="e.g., http://192.168.1.10:8000"
          />
        </div>
        <button onClick={handleSave} className="check-button">
          Save
        </button>
      </div>
    </div>
  );
}