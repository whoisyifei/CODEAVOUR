import React, { createContext, useState, useEffect, useContext } from "react";

// Create the context
const AppContext = createContext();

// Helper hook to use the context
export const useAppContext = () => useContext(AppContext);

// The provider component
export function AppContextProvider({ children }) {
  // === 1. All your app's state is here ===
  const [serverIp, setServerIp] = useState(() => {
    // Get saved IP from local storage, or default
    return localStorage.getItem("serverIp") || "http://localhost:8000";
  });
  
  const [isConnected, setIsConnected] = useState(true);
  const [currentTask, setCurrentTask] = useState(null); // This is for the progress display
  
  // Sensor data
  const [temperature, setTemperature] = useState("-");
  const [weight, setWeight] = useState("-");
  const [tempHistory, setTempHistory] = useState([]);
  
  const MAX_HISTORY_LENGTH = 30;

  // === 2. All fetch logic is here ===

  // Function to save the IP to state and local storage
  const updateServerIp = (newIp) => {
    // A little cleanup for the user
    if (newIp.endsWith("/")) {
      newIp = newIp.slice(0, -1);
    }
    localStorage.setItem("serverIp", newIp);
    setServerIp(newIp);
  };
  
  // Main data polling
  useEffect(() => {
    // --- 1. SENSOR POLLING ---
    const sensorInterval = setInterval(() => {
      // Fetch Temperature
      fetch(`${serverIp}/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ function: "get_temperature" }),
      })
      .then((res) => res.json())
      .then((j) => {
        setIsConnected(true);
        const tempString = j.result ?? "--";
        setTemperature(tempString);

        const newTemp = parseFloat(tempString);
        if (!isNaN(newTemp)) {
          setTempHistory(history => {
            const updated = [...history, newTemp];
            return updated.length > MAX_HISTORY_LENGTH ? updated.slice(-MAX_HISTORY_LENGTH) : updated;
          });
        }
      })
      .catch(() => setIsConnected(false));

      // Fetch Weight
      fetch(`${serverIp}/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ function: "get_weight" }),
      })
      .then(res => res.json())
      .then(j => setWeight(j.result ?? "--"))
      .catch(() => setIsConnected(false));
    }, 1200);

    // --- 2. TASK POLLING ---
    const taskInterval = setInterval(() => {
      fetch(`${serverIp}/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // === THIS IS THE NEW FUNCTION YOU MUST CREATE ON YOUR PYTHON SERVER ===
        body: JSON.stringify({ function: "get_current_task_status" }), 
      })
      .then(res => res.json())
      .then(j => {
        // e.g., result = { status: "moving_to_bed", patient_name: "John Doe" }
        // or result = null
        if (j.result && j.result.status !== "idle") {
          setCurrentTask(j.result);
        } else {
          setCurrentTask(null); // No active task
        }
      })
      .catch(() => setCurrentTask(null));
    }, 2000); // Check for a new task every 2 seconds

    return () => {
      clearInterval(sensorInterval);
      clearInterval(taskInterval);
    };
  }, [serverIp]); // Re-run this logic if the serverIp changes

  // === 3. Provide all state and functions to the app ===
  const value = {
    serverIp,
    updateServerIp,
    isConnected,
    setIsConnected,
    currentTask,
    temperature,
    weight,
    tempHistory,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}