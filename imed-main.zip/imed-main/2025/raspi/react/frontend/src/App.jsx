import { useState } from "react";

// === NEW: Import components and pages ===
import { Sidebar } from "./components/Sidebar";
import HomeScreen from "./pages/HomeScreen";
import AdjustmentScreen from "./pages/AdjustmentScreen";
import FolderScreen from "./pages/FolderScreen";
import SystemScreen from "./pages/SystemScreen";
import SettingsScreen from "./pages/SettingsScreen";
// Note: Placeholder component is removed as all pages are now being built.

export default function App() {
  const [page, setPage] = useState("home");

  let PageComponent;
  switch (page) {
    case "home":
      PageComponent = <HomeScreen />;
      break;
    case "adjustment":
      PageComponent = <AdjustmentScreen />;
      break;
    case "folder":
      PageComponent = <FolderScreen />;
      break;
    case "settings":
      PageComponent = <SettingsScreen />; // <-- NEW
      break;
    case "penguin":
      PageComponent = <SystemScreen />;
      break;
    default:
      PageComponent = <HomeScreen />;
  }

  return (
    <div className="app-container">
      <Sidebar current={page} onChange={setPage} />
      <div className="page-container">{PageComponent}</div>
    </div>
  );
}