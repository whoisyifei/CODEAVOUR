import React from "react";

export function StatBar({ icon, label, value }) {
  const safeValue = Math.max(0, Math.min(100, value || 0)); // Ensure value is 0-100

  return (
    <div className="stat-row">
      <div className="stat-icon-box">{icon}</div>
      <div className="stat-info">
        <div className="stat-label">{label}</div>
        <div className="stat-bar-container">
          <div className="stat-bar-fill" style={{ width: `${safeValue}%` }}></div>
        </div>
      </div>
      <div className="stat-value">{`${safeValue}%`}</div>
    </div>
  );
}