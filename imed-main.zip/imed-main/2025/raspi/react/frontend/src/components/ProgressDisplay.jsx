import React from "react";
import {
  FaCheck,
  FaBed,
  FaQrcode,
  FaIdCard,
  FaVials,
  FaClipboardCheck,
  FaHeartbeat,
  FaSpinner, // Import spinner for active state
} from "react-icons/fa";

export function ProgressDisplay({ task }) {
  // Define all possible steps
  // The 'id' MUST match the 'status' string from your Python server
  const allSteps = [
    { id: "moving_to_bed", label: "Moving to patient", icon: <FaBed /> },
    { id: "scanning_qr", label: "Scan Patient QR", icon: <FaQrcode /> },
    { id: "identification", label: "Identifying Patient", icon: <FaIdCard /> },
    { id: "dispensing", label: "Dispensing", icon: <FaVials /> },
    { id: "dispensed", label: "Dispensed", icon: <FaClipboardCheck /> },
    { id: "vital_check", label: "Vital Check", icon: <FaHeartbeat /> },
  ];

  // Find the index of the current step
  const currentStepIndex = allSteps.findIndex(step => step.id === task.status);

  // Helper component for each step row
  const ProgressStep = ({ icon, label, status }) => {
    return (
      <div className="progress-step">
        <div className={`progress-icon progress-step-icon-${status}`}>
          {status === "completed" ? <FaCheck /> : (status === "active" ? <FaSpinner /> : icon)}
        </div>
        <div className={`progress-label progress-step-label-${status}`}>
          {label}
        </div>
      </div>
    );
  };

  return (
    <div className="progress-container">
      <h2 className="progress-header">
        Task for: {task.patient_name || "Patient"}
      </h2>
      <div className="folder-list"> {/* Re-using folder-list for spacing */}
        {allSteps.map((step, index) => {
          let status = "pending";
          if (index < currentStepIndex) status = "completed";
          if (index === currentStepIndex) status = "active";
          
          return <ProgressStep key={step.id} icon={step.icon} label={step.label} status={status} />
        })}
      </div>
    </div>
  );
}