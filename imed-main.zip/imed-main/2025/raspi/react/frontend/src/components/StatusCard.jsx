import React from "react";

export function StatusCard({ icon, value }) {
  return (
    <div className="status-card">
      <div className="status-icon">{icon}</div>
      <div className="status-value">{value}</div>
    </div>
  );
}