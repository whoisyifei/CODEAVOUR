import React from "react";

export function GraphDisplay({ data }) {
  const yAxisLabels = ["300", "255", "210", "165", "120", "75", "30", "-15"];

  const MIN_TEMP = -15;
  const MAX_TEMP = 300;
  const range = MAX_TEMP - MIN_TEMP;

  if (data.length < 2) {
    return (
      <div className="graph-container">
        <div className="y-axis">
          {yAxisLabels.map((label) => (
            <span key={label}>{label}</span>
          ))}
        </div>
        <div className="graph-panel">
          <svg
            width="100%"
            height="100%"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            className="svg-container"
          ></svg>
        </div>
      </div>
    );
  }

  const normalizeTemp = (temp) => {
    if (range === 0) return 100;
    let percentage = ((temp - MIN_TEMP) / range) * 100;
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;
    return 100 - percentage;
  };

  const numSegments = data.length - 1;
  const points = data.map((temp, index) => {
      const x = (index / numSegments) * 100; 
      const y = normalizeTemp(temp);
      return `${x},${y}`;
    }).join(" ");
  const fillPoints = `0,100 ${points} 100,100`;

  return (
    <div className="graph-container">
      <div className="y-axis">
        {yAxisLabels.map((label) => (
          <span key={label}>{label}</span>
        ))}
      </div>
      <div className="graph-panel">
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="svg-container"
        >
          <defs>
            <linearGradient id="gradient" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#4A90E2" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#4A90E2" stopOpacity="0" />
            </linearGradient>
          </defs>
          <polyline fill="url(#gradient)" stroke="none" points={fillPoints} />
          <polyline fill="none" stroke="#4A90E2" strokeWidth="2.5" points={points} />
        </svg>
      </div>
    </div>
  );
}