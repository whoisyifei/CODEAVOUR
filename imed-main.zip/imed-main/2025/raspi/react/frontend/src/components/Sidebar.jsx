import React from "react";
import { FaHome, FaSlidersH, FaCog, FaFolder, FaLinux } from "react-icons/fa";

export function Sidebar({ current, onChange }) {
  return (
    <div className="sidebar">
      <SidebarButton
        icon={<FaHome />}
        selected={current === "home"}
        onClick={() => onChange("home")}
      />
      <SidebarButton
        icon={<FaSlidersH />}
        selected={current === "adjustment"}
        onClick={() => onChange("adjustment")}
      />
      <SidebarButton
        icon={<FaFolder />}
        selected={current === "folder"}
        onClick={() => onChange("folder")}
      />
      <SidebarButton
        icon={<FaCog />}
        selected={current === "settings"}
        onClick={() => onChange("settings")}
      />
      <SidebarButton
        icon={<FaLinux />}
        selected={current === "penguin"}
        onClick={() => onChange("penguin")}
      />
    </div>
  );
}

function SidebarButton({ icon, selected, onClick }) {
  // Dynamically set the className
  const className = `sidebar-button ${selected ? "selected" : ""}`;
  
  return (
    <div
      onClick={onClick}
      className={className}
    >
      {icon}
    </div>
  );
}