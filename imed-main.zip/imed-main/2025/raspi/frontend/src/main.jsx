import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
// === NEW ===
import { AppContextProvider } from './context/AppContext.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* === NEW WRAPPER === */}
    <AppContextProvider>
      <App />
    </AppContextProvider>
  </React.StrictMode>,
)