import React, { useState, useEffect, useCallback, useRef, createContext, useContext } from "react";

// --- Configuration ---
// All API calls must go to the Flask server running on port 5000
const API_BASE_URL = "http://127.0.0.1:5000/api";
const LOG_FETCH_INTERVAL = 3000; // 3 seconds
const STATUS_FETCH_INTERVAL = 1000; // 1 second
const TASK_FETCH_INTERVAL = 500; // 0.5 second (Faster update for real-time progress)

// --- CONTEXT DEFINITION (Consolidated into this file) ---
const AppContext = createContext();

export const useAppContext = () => useContext(AppContext);

// Helper function for API control actions
// This function will be provided by the context
const postControlAction = async (actionName) => {
    const endpoint = `${API_BASE_URL}/control`;
    try {
        console.log(`[API Control] Sending action: ${actionName}`);
        
        const response = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: actionName }),
        });

        if (!response.ok) {
            // Try to read error message from body if available
            const errorBody = await response.json().catch(() => ({ message: 'Unknown server error.' }));
            throw new Error(`API Control failed (Status ${response.status}): ${errorBody.message}`);
        }

        const result = await response.json();
        console.log(`[API Control] Success: ${result.message}`);
        return result;

    } catch (error) {
        console.error(`[API Control] Error posting action '${actionName}':`, error.message);
        // Provide a simple error message to the user if needed.
        return { status: "error", message: error.message };
    }
};

/**
 * Provides the postControlAction function to all children components.
 */
export function AppContextProvider({ children }) {
    const contextValue = {
        // Wrap postControlAction in useCallback for optimization
        postControlAction: useCallback(postControlAction, []),
    };

    return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>;
}


// --- ICONS (Same as before) ---
const CheckCircleIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
);
const Loader2Icon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
);
const XCircleIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>
);
const ServerIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" x2="6" y1="6" y2="6"/><line x1="18" x2="18" y1="6" y2="6"/></svg>
);
const LightbulbIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 14c.2-1 .5-2 1-3 1-2 2.5-3.78 4.28-5.12 1.4-.92 2.85-2.34 3.72-5.7h-9.7"/><path d="M16 17H5.97L11 3l5 14Z"/><line x1="12" x2="12" y1="17" y2="20"/><line x1="8" x2="8" y1="20" y2="21"/><line x1="16" x2="16" y1="20" y2="21"/></svg>
);
const FanIcon = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8.28 17.72a3.53 3.53 0 0 0-4.99-4.99L2 16"/><path d="M17.72 8.28a3.53 3.53 0 0 0 4.99 4.99L22 8"/><path d="M8.28 6.28a3.53 3.53 0 0 0-4.99 4.99L2 12"/><path d="M17.72 17.72a3.53 3.53 0 0 0 4.99 4.99L22 16"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M20 12h2"/><path d="M2 12h2"/><path d="M16.95 7.05l-1.41 1.41"/><path d="M7.05 16.95l-1.41 1.41"/><path d="M7.05 7.05l1.41 1.41"/><path d="M16.95 16.95l1.41 1.41"/></svg>
);

// === Reusable Style Objects ===
const styles = {
    appContainer: {
        minHeight: '100vh',
        backgroundColor: '#0F172A', // Slate-900 (Dark background)
        color: '#E2E8F0', // Light text
        fontFamily: 'Inter, sans-serif',
        padding: '2rem',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    header: {
        width: '100%',
        maxWidth: '80rem',
        marginBottom: '1.5rem',
    },
    headerTitle: {
        fontSize: '2.25rem',
        fontWeight: '800',
        textAlign: 'center',
        color: '#2DD4BF', // Teal-400
        letterSpacing: '0.05em',
    },
    connectionStatus: {
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'center',
        fontSize: '0.875rem',
        color: '#6B7280',
        marginTop: '0.5rem',
    },
    statusOnline: { color: '#10B981' }, // Green
    statusOffline: { color: '#EF4444' }, // Red
    mainContent: {
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 3fr)', // 2 parts for status, 3 parts for logs/task
        gap: '2rem',
        width: '100%',
        maxWidth: '80rem',
    },
    sectionCard: {
        backgroundColor: '#1E293B', // Slate-800
        borderRadius: '0.5rem',
        padding: '1.5rem',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)',
    },
    sectionTitle: {
        fontSize: '1.25rem',
        fontWeight: '700',
        color: '#94A3B8', // Slate-400
        marginBottom: '1rem',
        borderBottom: '1px solid #334155', // Slate-700
        paddingBottom: '0.5rem',
    },
    circleButton: {
        backgroundColor: '#334155', // Slate-700
        color: '#94A3B8',
        border: 'none',
        borderRadius: '50%',
        padding: '0.75rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'background-color 0.2s, color 0.2s',
        cursor: 'pointer',
    },
};

// Dynamic Styles for hover effects
const getDynamicStyles = (key) => {
    switch (key) {
        case 'circleButtonHoverLight':
            return {
                ':hover': {
                    backgroundColor: '#475569', // Slate-600
                    color: '#E2E8F0',
                }
            };
        default:
            return {};
    }
}

// === Component: SystemStatusMonitor ===

const SystemStatusMonitor = ({ statusData }) => {
    return (
        <div style={styles.sectionCard}>
            <h2 style={styles.sectionTitle}>System Status Monitor</h2>
            <div className="space-y-3">
                {statusData.map((stage, index) => (
                    <div key={index} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.5rem 0', borderBottom: index < statusData.length - 1 ? '1px dotted #334155' : 'none' }}>
                        <span style={{ fontWeight: '500', color: '#E2E8F0' }}>{stage.stage}</span>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: '1', paddingLeft: '1rem' }}>
                            <span style={{ fontSize: '0.875rem', color: stage.is_complete ? '#94A3B8' : '#FBBF24', fontStyle: 'italic', flex: '1' }}>
                                {stage.message}
                            </span>
                            {stage.is_complete ? (
                                <CheckCircleIcon size={20} style={{ color: '#10B981' }} title="Complete" />
                            ) : (
                                <Loader2Icon size={20} style={{ color: '#3B82F6' }} title="In Progress" />
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

// === Component: TaskProgress (Handles real-time updates) ===

const stages = ["IDLE", "MOVING", "IDENTIFYING", "DISPENSING", "FINISHED"];

const TaskProgress = ({ taskData }) => {
    if (!taskData) {
        return (
            <div style={styles.sectionCard} className="flex flex-col items-center justify-center h-48">
                <p style={{ color: '#94A3B8' }}>Robot is currently idle and awaiting a schedule.</p>
                <ServerIcon size={32} style={{ color: '#94A3B8', marginTop: '1rem' }} />
            </div>
        );
    }

    // The 'IDLE' stage from the backend is transient; we calculate progress based on the main stages.
    const currentStageIndex = stages.indexOf(taskData.current_stage);
    
    // Calculate progress as a percentage. It reaches 100% at 'FINISHED'.
    const progressPercent = Math.min(100, (currentStageIndex / (stages.length - 1)) * 100); 

    return (
        <div style={styles.sectionCard}>
            <h2 style={{ ...styles.sectionTitle, color: '#2DD4BF' }}>Active Dispense Task: {taskData.task_id}</h2>
            
            <div className="mb-4">
                <p className="text-lg font-semibold" style={{ color: '#E2E8F0' }}>Patient: <span className="text-teal-300">{taskData.patient_name}</span></p>
                <p className="text-sm" style={{ color: '#94A3B8' }}>Meds: <span className="font-mono text-xs">{taskData.medication}</span></p>
                <p className="text-sm" style={{ color: '#94A3B8', fontStyle: 'italic' }}>Status: <span className="text-yellow-300">{taskData.message || taskData.current_stage}</span></p>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-700 rounded-full h-2.5 mb-4">
                <div 
                    className="h-2.5 rounded-full bg-teal-500 transition-all duration-500 ease-out" 
                    style={{ width: `${progressPercent}%` }}
                ></div>
            </div>

            {/* Stage Indicators */}
            <div className="flex justify-between text-xs font-mono">
                {stages.map((stage, index) => (
                    <div 
                        key={index} 
                        style={{ 
                            textAlign: 'center',
                            color: index <= currentStageIndex ? '#2DD4BF' : '#475569',
                            fontWeight: index === currentStageIndex ? 'bold' : 'normal',
                            position: 'relative',
                        }}
                    >
                        {stage}
                        {index === currentStageIndex && (
                            <span 
                                className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 w-2 h-2 rounded-full bg-teal-500"
                            ></span>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

// === Component: SchedulerMonitor (Logs) ===

const LogEntry = ({ log }) => {
    const { level, component, message, timestamp } = log;
    
    let color = '#E2E8F0'; // INFO/DEBUG
    let icon = null;

    switch (level) {
        case 'CRITICAL':
        case 'ERROR':
            color = '#EF4444'; // Red
            icon = <XCircleIcon size={14} style={{ marginRight: '0.25rem' }} />;
            break;
        case 'WARN':
            color = '#FBBF24'; // Yellow
            break;
        case 'ACTION':
        case 'ACTION_COMPLETE':
            color = '#3B82F6'; // Blue
            break;
        case 'INFO':
        case 'DEBUG':
        default:
            color = '#94A3B8'; // Slate-400
            break;
    }

    return (
        <div style={{ display: 'flex', fontSize: '0.75rem', color: '#94A3B8' }}>
            <span style={{ minWidth: '100px', flexShrink: 0 }}>[{timestamp.split(' ')[1]}]</span>
            <span style={{ minWidth: '100px', flexShrink: 0, fontWeight: 'bold', color: color }}>[{level}]</span>
            <span style={{ minWidth: '120px', flexShrink: 0, color: '#6B7280' }}>[{component}]</span>
            <span style={{ color: color, flexGrow: 1, whiteSpace: 'pre-wrap' }}>
                {icon}
                {message}
            </span>
        </div>
    );
};

const SchedulerMonitor = ({ logs }) => {
    const logContainerRef = useRef(null);

    // Scroll to bottom whenever logs change (to show newest log)
    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [logs]);

    // FIX 1: The API returns logs newest-first (index 0 is newest). 
    // We reverse them here so that they are oldest-first, and the scroll-to-bottom
    // ensures the newest log (now at the end of the array) is visible.
    const logsChronological = [...logs].reverse(); 

    return (
        <div style={styles.sectionCard}>
            <h2 style={styles.sectionTitle}>Robot Scheduler Log</h2>
            <div 
                ref={logContainerRef}
                style={{ height: '500px', overflowY: 'scroll', backgroundColor: '#0F172A', padding: '0.5rem', borderRadius: '0.25rem', border: '1px solid #334155' }}
            >
                {logsChronological.length === 0 ? (
                    <p style={{ color: '#6B7280', textAlign: 'center', paddingTop: '1rem' }}>Awaiting log entries...</p>
                ) : (
                    logsChronological.map((log, index) => <LogEntry key={index} log={log} />)
                )}
            </div>
        </div>
    );
};

// === Main App Content Component (Uses Context) ===
const AppContent = () => {
    const [logData, setLogData] = useState([]);
    const [statusData, setStatusData] = useState([]);
    const [taskData, setTaskData] = useState(null);
    const [isApiOnline, setIsApiOnline] = useState(false);
    const [isLightHover, setIsLightHover] = useState(false);
    const [isFanHover, setIsFanHover] = useState(false);
    
    // Hook into the context to get the control function
    const { postControlAction } = useAppContext();

    // Function to fetch data from a given endpoint
    const fetchData = useCallback(async (endpoint, setDataState, checkOnline = false) => {
        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setDataState(data);
            if (checkOnline) {
                setIsApiOnline(true);
            }
        } catch (error) {
            console.error(`Error fetching ${endpoint}:`, error);
            if (checkOnline) {
                setIsApiOnline(false);
            }
            // Clear task data on API failure to reflect the robot is offline
            if (endpoint === '/task') {
                setDataState(null);
            }
        }
    }, []);

    // 1. Log Data Fetcher
    useEffect(() => {
        // Fetch logs and check API status simultaneously
        const fetchLogs = () => fetchData('/logs', setLogData, true);
        const logInterval = setInterval(fetchLogs, LOG_FETCH_INTERVAL);
        fetchLogs(); // Initial fetch
        return () => clearInterval(logInterval);
    }, [fetchData]);

    // 2. System Status Fetcher (Initialization/Startup progress)
    useEffect(() => {
        const fetchStatus = () => fetchData('/status', setStatusData);
        const statusInterval = setInterval(fetchStatus, STATUS_FETCH_INTERVAL);
        fetchStatus(); // Initial fetch
        return () => clearInterval(statusInterval);
    }, [fetchData]);
    
    // 3. Current Task Fetcher (Dispense progress bar)
    // The frequency is higher (TASK_FETCH_INTERVAL = 500ms) to ensure real-time progress updates
    useEffect(() => {
        const fetchTask = () => fetchData('/task', setTaskData);
        const taskInterval = setInterval(fetchTask, TASK_FETCH_INTERVAL);
        fetchTask(); // Initial fetch
        return () => clearInterval(taskInterval);
    }, [fetchData]);

    return (
        <div style={styles.appContainer}>
            <header style={styles.header}>
                <h1 style={styles.headerTitle}>IMED ROBOT CONTROL SYSTEM</h1>
                <div style={styles.connectionStatus}>
                    <ServerIcon size={16} style={{ marginRight: '0.5rem' }} />
                    API Status: 
                    <span style={isApiOnline ? styles.statusOnline : styles.statusOffline}>
                        {isApiOnline ? ' ONLINE' : ' OFFLINE'}
                    </span>
                    <span style={{ marginLeft: '0.5rem', color: '#6B7280' }}>({API_BASE_URL.replace('/api', '')})</span>
                </div>
            </header>

            <main style={styles.mainContent}>
                
                {/* Left Column: Task Progress & System Status */}
                <div className="space-y-6">
                    <TaskProgress taskData={taskData} />
                    <SystemStatusMonitor statusData={statusData} />

                    {/* Manual Controls Section */}
                    <div style={styles.sectionCard}>
                        <h2 style={styles.sectionTitle}>Manual Robot Controls</h2>
                        <div className="flex space-x-4">
                            <button 
                                title="Toggle Light" 
                                style={{ 
                                    ...styles.circleButton, 
                                    ...(isLightHover && getDynamicStyles('circleButtonHoverLight'))
                                }}
                                onMouseEnter={() => setIsLightHover(true)}
                                onMouseLeave={() => setIsLightHover(false)}
                                onClick={() => postControlAction('TOGGLE_LIGHT')}
                            >
                                <LightbulbIcon size={24} />
                            </button>
                            <button 
                                title="Toggle Fan" 
                                style={{ 
                                    ...styles.circleButton,
                                    ...(isFanHover && getDynamicStyles('circleButtonHoverLight')) 
                                }}
                                onMouseEnter={() => setIsFanHover(true)}
                                onMouseLeave={() => setIsFanHover(false)}
                                onClick={() => postControlAction('TOGGLE_FAN')}
                            >
                                <FanIcon size={24} />
                            </button>
                        </div>
                    </div>
                </div>
                
                {/* Right Column: Robot Scheduler Monitor */}
                <div className="space-y-6">
                    <SchedulerMonitor logs={logData} />
                </div>

            </main>
        </div>
    );
}

// === Main App Component (Wrapper) ===
// This is the default export and wraps the content in the provider.
export default function App() {
    return (
        <AppContextProvider>
            <AppContent />
        </AppContextProvider>
    );
}