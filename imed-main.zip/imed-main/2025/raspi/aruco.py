import time
import cv2
import cv2.aruco as aruco
import numpy as np
import os
from datetime import datetime

# ArUco setup
aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_5X5_100)
parameters = aruco.DetectorParameters_create()

def set_resolution(cap, width, height):
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    return int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

def detect_marker_positions(max_labels=8, screenshot_dir='screenshots'):
    # Setup camera
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))

    # Try to set highest available resolution
    w, h = set_resolution(cap, 1920, 1080)
    if (w, h) != (1920, 1080):
        print(f"⚠️ 1920x1080 not supported. Trying 1280x720...")
        w, h = set_resolution(cap, 1280, 720)
        if (w, h) != (1280, 720):
            print(f"⚠️ 1280x720 not supported. Falling back to 640x480...")
            w, h = set_resolution(cap, 640, 480)

    print(f"📸 Camera resolution: {w}x{h}")

    # Prepare output
    position_table = {}
    last_frame = None

    # Create screenshot directory if not exists
    os.makedirs(screenshot_dir, exist_ok=True)

    if not cap.isOpened():
        print("❌ Failed to open camera.")
        return position_table

    print("🔍 Starting marker detection...")
    print(f"📋 Waiting for {max_labels} markers per side (front and back)...")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("⚠️ Failed to grab frame.")
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)

        if ids is not None:
            aruco.drawDetectedMarkers(frame, corners, ids)

            markers = []
            for i in range(len(ids)):
                marker_id = int(ids[i][0])
                center = np.mean(corners[i][0], axis=0)
                cx, cy = center
                markers.append({'id': marker_id, 'cx': cx, 'cy': cy})

            # Split markers left/right based on center x-coordinate
            frame_mid = frame.shape[1] / 2
            left = [m for m in markers if m['cx'] < frame_mid]
            right = [m for m in markers if m['cx'] >= frame_mid]

            # Sort top to bottom
            left_sorted = sorted(left, key=lambda m: m['cy'])
            right_sorted = sorted(right, key=lambda m: m['cy'])

            # Reset position table every frame
            position_table.clear()

            # Label front (left side)
            for idx, marker in enumerate(left_sorted[:max_labels]):
                label = chr(ord('A') + idx)
                side = 'front'
                position_table[marker['id']] = (side, label)
                cx, cy = int(marker['cx']), int(marker['cy'])
                cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
                cv2.putText(frame, f"{side}-{label}", (cx + 10, cy),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            # Label back (right side)
            for idx, marker in enumerate(right_sorted[:max_labels]):
                label = chr(ord('A') + idx)
                side = 'back'
                position_table[marker['id']] = (side, label)
                cx, cy = int(marker['cx']), int(marker['cy'])
                cv2.circle(frame, (cx, cy), 5, (0, 0, 255), -1)
                cv2.putText(frame, f"{side}-{label}", (cx + 10, cy),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

            # ✅ Save the annotated frame after labels are drawn
            last_frame = frame.copy()

        # Show window
        cv2.imshow("ArUco Detection", frame)

        # Count how many labels have been assigned
        front_labels = [v for v in position_table.values() if v[0] == 'front']
        back_labels = [v for v in position_table.values() if v[0] == 'back']

        if len(front_labels) >= max_labels and len(back_labels) >= max_labels:
            print("✅ All markers detected!")

            # Save screenshot
            time.sleep(1)
            timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            filename = f"detection_{timestamp}.jpg"
            filepath = os.path.join(screenshot_dir, filename)
            if last_frame is not None:
                cv2.imwrite(filepath, last_frame)
                print(f"📸 Screenshot saved to: {filepath}")
            else:
                print("⚠️ No frame captured to save.")
            break

        # Manual exit option
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("🛑 Detection manually stopped.")
            break

    cap.release()
    cv2.destroyAllWindows()
    print(f"📋 Final Marker Positions: {position_table}")
    return position_table



