# main.py (raspi) - CHECK ALL SCHEDULES AND MATCH TIME

import time
import buzzer_control
from datetime import datetime, timedelta

SERVER_URL = "http://192.168.1.103:5000"
PATIENT_ID = 1  # Your device's assigned patient

# Time window for matching (±5 minutes)
TIME_MARGIN_MINUTES = 5

def get_schedule():
    try:
        response = buzzer_control.get(f"{SERVER_URL}/schedule")
        if response.status_code == 200:
            return response.json()
        else:
            print("Failed to fetch schedule:", response.text)
            return []
    except Exception as e:
        print("[ERROR] Failed to reach server:", e)
        return []

def is_within_time_window(scheduled_time_str):
    try:
        now = datetime.now().time()
        scheduled_time = datetime.strptime(scheduled_time_str, "%H:%M:%S").time()

        now_dt = datetime.combine(datetime.today(), now)
        scheduled_dt = datetime.combine(datetime.today(), scheduled_time)

        delta = abs(now_dt - scheduled_dt)
        return delta <= timedelta(minutes=TIME_MARGIN_MINUTES)
    except Exception as e:
        print(f"[ERROR] Time comparison failed: {e}")
        return False

# Main loop
while True:
    print("[INFO] Checking all schedules...")
    schedule = get_schedule()
    for task in schedule:
        if task.get("task") == "dispense" and is_within_time_window(task.get("time")):
            patient_id = task.get("patient_id")
            print(f"[TRIGGER] It's time to dispense for patient ID {patient_id} at scheduled time {task.get('time')}")
        else:
            print(f"[INFO] No matching task right now. Current time: {datetime.now().strftime('%H:%M:%S')}")
    time.sleep(60)
