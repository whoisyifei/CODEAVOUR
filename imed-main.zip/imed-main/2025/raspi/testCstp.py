import time
import board
import digitalio
from adafruit_motor import stepper

# --------------------- Hardware Configuration ---------------------
DELAY = 0.001  # Initial delay between steps (adjust for optimal performance)

# Motor driver pins (using your original setup)
coils = (
    digitalio.DigitalInOut(board.D16),  # A1
    digitalio.DigitalInOut(board.D25),  # A2
    digitalio.DigitalInOut(board.D23),  # B1
    digitalio.DigitalInOut(board.D24),  # B2
)


for coil in coils:
    coil.direction = digitalio.Direction.OUTPUT

motor = stepper.StepperMotor(coils[0], coils[1], coils[2], coils[3], microsteps=None)

# --------------------- Motor Specifications ---------------------
# NEMA17HS4401 specific parameters
STEPS_PER_REV = 200      # 1.8° step angle (200 steps/revolution)
ROD_PITCH = 2.0          # 2mm linear travel per revolution
STEPS_PER_MM = STEPS_PER_REV / ROD_PITCH  # 100 steps/mm

# --------------------- Position Configuration ---------------------
# Default positions (in mm from home) - customize to your setup
POSITIONS = {
    'A': 0.0,    # Home position
    'B': 10.0,    # Example positions - measure your actual distances
    'C': 20.0,
    'D': 30.0,
    'E': 40.0,
    'F': 50.0,
    'G': 60.0,
    'H': 70.0
}

# --------------------- System State ---------------------
current_pos_mm = None    # Current position in mm
is_homed = False         # Homing status flag

# --------------------- Movement Functions ---------------------
def move_to_position(target):
    """Move to a predefined position (A-H)"""
    global current_pos_mm, is_homed
    
    if target not in POSITIONS:
        print(f"Invalid position. Choose from {list(POSITIONS.keys())}")
        return
    
    if not is_homed:
        print("System not homed. Performing homing routine...")
        home()
        if not is_homed:
            return
    
    target_mm = POSITIONS[target]
    distance = target_mm - current_pos_mm
    steps = int(round(distance * STEPS_PER_MM))
    
    print(f"Moving from {current_pos_mm:.2f}mm to {target_mm:.2f}mm")
    print(f"Distance: {distance:.2f}mm | Steps: {steps}")
    
    if steps != 0:
        move_stepper(steps)
        current_pos_mm = target_mm
    print(f"Arrived at {target} ({current_pos_mm:.2f}mm)")

def move_stepper(steps):
    """Move the stepper motor a specific number of steps"""
    direction = stepper.FORWARD if steps > 0 else stepper.BACKWARD
    steps = abs(steps)
    
    # Dynamic speed control - starts slower, accelerates, then decelerates
    initial_delay = DELAY * 2
    final_delay = DELAY / 2
    ramp_steps = min(steps // 3, 50)  # Number of steps for acceleration
    
    try:
        for step in range(steps):
            # Calculate dynamic delay for acceleration/deceleration
            if step < ramp_steps:
                # Accelerating
                delay = initial_delay - (initial_delay - DELAY) * step/ramp_steps
            elif step > steps - ramp_steps:
                # Decelerating
                delay = DELAY + (final_delay - DELAY) * (step - (steps - ramp_steps))/ramp_steps
            else:
                # Constant speed
                delay = DELAY
            
            motor.onestep(direction=direction)
            time.sleep(max(delay, 0.0001))  # Prevent zero delay
        
    except KeyboardInterrupt:
        print("\nMovement interrupted!")
    finally:
        motor.release()

def home():
    """Home the system to position A"""
    global current_pos_mm, is_homed
    
    print("\n=== Homing Procedure ===")
    print("1. Please ensure the carriage is near position A")
    print("2. The system will move slowly backward until stopped")
    
    # In a real system, you would:
    # 1. Move backward until hitting a limit switch
    # 2. Set that position as 0mm (A)
    # For simulation, we'll assume we're at A
    
    input("Press Enter when ready to home...")
    
    # Simulate homing by moving to A
    current_pos_mm = POSITIONS['A']
    is_homed = True
    print(f"Homing complete. Now at position A (0.00mm)")

# --------------------- Calibration Functions ---------------------
def calibrate_system():
    """Calibrate the position system"""
    print("\n=== System Calibration ===")
    print(f"Current steps/mm: {STEPS_PER_MM} (based on {STEPS_PER_REV} steps/rev and {ROD_PITCH}mm pitch)")
    
    print("\nOptions:")
    print("1. Calibrate steps/mm (advanced)")
    print("2. Calibrate position distances")
    print("3. Return to main menu")
    
    choice = input("Select option: ").strip()
    
    if choice == '1':
        calibrate_steps_per_mm()
    elif choice == '2':
        calibrate_positions()
    else:
        return

def calibrate_positions():
    """Recalibrate the position distances"""
    global POSITIONS, current_pos_mm
    
    print("\n=== Position Calibration ===")
    print("Current positions:")
    for pos, mm in sorted(POSITIONS.items()):
        print(f"{pos}: {mm}mm")
    
    print("\nEnter new distances from position A (in mm):")
    new_positions = {'A': 0.0}
    
    try:
        for pos in ['B', 'C', 'D', 'E', 'F', 'G', 'H']:
            dist = float(input(f"Distance to {pos}: "))
            new_positions[pos] = dist
        
        POSITIONS = new_positions
        print("\nNew positions saved:")
        for pos, mm in sorted(POSITIONS.items()):
            print(f"{pos}: {mm}mm")
        
        # Update current position if we're at a known position
        if current_pos_mm is not None:
            closest_pos = min(POSITIONS.items(), key=lambda x: abs(x[1] - current_pos_mm))
            current_pos_mm = closest_pos[1]
            print(f"Updated current position to {closest_pos[0]} ({current_pos_mm}mm)")
            
    except ValueError:
        print("Invalid input. Calibration aborted.")

# --------------------- Main Interface ---------------------
def main_menu():
    """Main user interface"""
    print("\n=== NEMA17HS4401 Position Control ===")
    print(f"Motor: NEMA17HS4401 (200 steps/rev)")
    print(f"Rod Pitch: {ROD_PITCH}mm")
    print(f"Steps/mm: {STEPS_PER_MM}")
    
    while True:
        print("\n===== MAIN MENU =====")
        print(f"Current position: {current_pos_mm if current_pos_mm is not None else 'Unknown'}mm")
        if current_pos_mm is not None:
            closest_pos = min(POSITIONS.items(), key=lambda x: abs(x[1] - current_pos_mm))
            print(f"Closest labeled position: {closest_pos[0]} ({closest_pos[1]}mm)")
        
        print("\nOptions:")
        print("1. Move to position (A-H)")
        print("2. Manual move (by mm)")
        print("3. System calibration")
        print("4. Home system")
        print("5. Exit")
        
        choice = input("Select option: ").strip().upper()
        
        if choice in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']:
            move_to_position(choice)
        elif choice == '2':
            manual_move()
        elif choice == '3':
            calibrate_system()
        elif choice == '4':
            home()
        elif choice == '5':
            print("Exiting...")
            motor.release()
            break
        else:
            print("Invalid option")

def manual_move():
    """Manual movement by mm distance"""
    global current_pos_mm
    
    if not is_homed:
        print("System must be homed first")
        home()
        if not is_homed:
            return
    
    try:
        distance = float(input("Enter distance to move (+/- mm): "))
        steps = int(round(distance * STEPS_PER_MM))
        
        if steps == 0:
            print("No movement needed")
            return
        
        print(f"Moving {'forward' if steps > 0 else 'backward'} {abs(distance):.2f}mm ({abs(steps)} steps)")
        move_stepper(steps)
        current_pos_mm += distance
        print(f"New position: {current_pos_mm:.2f}mm")
        
    except ValueError:
        print("Invalid input")

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        motor.release()
        print("\nProgram terminated by user")
    finally:
        motor.release()

